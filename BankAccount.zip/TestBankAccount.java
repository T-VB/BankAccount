public class TestBankAccount {
    public static void main(String[] args){
        //instantiate new BankAccount
        BankAccount myAccount = new BankAccount();
        myAccount.depositAmount(60, "checking"); //deposit $60 into checking account
        myAccount.depositAmount(250, "savings");//deposit $250 intro savings account
        //testing myAccount balances
        System.out.println(myAccount.getCheckingBalance()); //60.00
        System.out.println(myAccount.getSavingsBalance()); //250.00
        System.out.println(BankAccount.totalFunds); //310.00
        System.out.println(BankAccount.numberOfAccounts); //1
        
        myAccount.withdrawAmount(260, "savings");
        System.out.println(myAccount.getCheckingBalance()); //should read "insufficient funds"

        BankAccount otherAccount = new BankAccount();
        otherAccount.depositAmount(100, "checking");
        otherAccount.depositAmount(730, "savings");
        //testing otherAccount balances
        System.out.println(otherAccount.getCheckingBalance()); //100.00
        System.out.println(otherAccount.getSavingsBalance()); //730.00
        System.out.println(BankAccount.totalFunds); //1140 (310 + 830)
        System.out.println(BankAccount.numberOfAccounts); //2
    }
}