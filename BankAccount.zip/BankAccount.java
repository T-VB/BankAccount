public class BankAccount {
    //below are member variables, what the object 'has'
    private double checkingBalance; //instance
    private double savingsBalance; //instance
    public static int numberOfAccounts = 0; //static class member (belong to BankAccount class itself)
    public static double totalFunds = 0; //static class member (belong to the BankAccount class itself)

    //constructor method (how to create a bank account, first creation)
    public BankAccount(){
        this.checkingBalance = 0;
        this.savingsBalance = 0;
        BankAccount.numberOfAccounts += 1;
    }

    //'get' method for checking balance
    public double getCheckingBalance(){
        return this.checkingBalance;
    }

    //'get' method for savings balance
    public double getSavingsBalance(){
        return this.savingsBalance;
    }

    //Create a method that will allow a user to deposit money into either 
    //the checking or saving, be sure to add to total amount stored.
    public void depositAmount(double amount, String account){
        //CHECK COUNT, if the account equals 'savings, add amount to this savings account
        if (account.equals("savings")) //or if (account == "savings") / or use boolean to check isSavings/isChecking
            this.savingsBalance += amount;
        
        //else if the account equals 'checking', add amount to this checking account
        else if (account.equals("checking")) 
            this.checkingBalance += amount;
        //add amount to totalFunds
        this.totalFunds += amount;
        
    }


    //Create a method to withdraw money from one balance. 
    //Do not allow withdrawal if there are insufficient funds.
    public void withdrawAmount(double amount, String account){
        //if the account equals 'savings', subtract amount to this savingsBalance account
        if (account.equals("savings")){
            //withdrawal amount cannot exceed account balance.
            if (amount > this.savingsBalance) {
                System.out.println("Insufficient Funds");
                return;
            }
            this.savingsBalance -= amount;
        }
        else {
            if (amount > this.checkingBalance) {
                System.out.println("Insufficient Funds");
                return;
            }
            this.checkingBalance -=amount;
        }
        }
}

    //Create a method to see the total money from the checking and savings.
    

    //Users should not be able to set any of the attributes from the class